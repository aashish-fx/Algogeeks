import classes from './Loadingspinner.module.css';

const Loadingspinner = () => {
  return <div className={classes.spinner}></div>;
}

export default Loadingspinner;