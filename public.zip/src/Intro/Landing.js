import React from 'react';
import styles from './Landing.module.css';

const Landing =(props)=>{
    //const [init,setvalue]=useState(false);
    
    
  return (
      <div>
          
          <section className={styles.banner}>
       <div className={styles.container1}>
        <div className={styles.scene}>
        <h2 className={styles.text}>
            <span  >A</span>
            <span  >L</span>
            <span  >G</span>
            <span >O</span>
            <span >G</span>
            <span  >E</span>
            <span >E</span>
            <span >K</span>
            <span  >S</span>
        </h2>

        </div> 
       
    </div>
    </section>
    
    
    

      </div>
  );
};
export default Landing 